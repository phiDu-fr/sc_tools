import os
import time
import socket
import threading
import uuid
import json
import base64
import requests
import re
import hashlib
import urllib.parse
import subprocess
import xml.etree.ElementTree as ET
import xml.sax.saxutils as saxutils
from flask import Flask, request, Response
import vlc
from zeroconf import ServiceInfo, Zeroconf
import logging

# --- UTILITAIRE RESEAU ---
def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

LOCAL_IP = get_local_ip()

# --- LECTURE CONFIGURATION .ENV ---
def load_env_config():
    """Charge les variables depuis le fichier .env[cite: 4]."""
    env_paths = ["/home/pi/sc_tools/.env", "/home/pi/sc_tools/data/.env", ".env"]
    for env_path in env_paths:
        if os.path.exists(env_path):
            try:
                env_data = {}
                with open(env_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            if '=' in line:
                                k, v = line.split('=', 1)
                                env_data[k.strip()] = v.strip()
                print(f"✅ Configuration chargée depuis {env_path}")
                return env_data
            except Exception as e:
                print(f"⚠️ Erreur de lecture de {env_path} : {e}")
    return {}

ENV_CONFIG = load_env_config()

# --- CONFIGURATION DE L'EMULATEUR ---
DEVICE_NAME = "Pi-Bluetooth"
MAC_ADDRESS = ''.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff) for ele in range(0,8*6,8)][::-1]).upper()
HTTP_PORT = 8090
WS_PORT = 8080

# Extraction dynamique depuis le .env[cite: 4]
MARGE_PORT = int(ENV_CONFIG.get("SC_MARGE_PORT", 8000))
MARGE_ADDR = ENV_CONFIG.get("SC_MARGE_ADDR", "127.0.0.1")

# --- CONFIGURATION MATERIELLE ---
BT_MAC_ADDRESS = ENV_CONFIG.get("SC_MARGE_ADDR", "70:99:1C:AF:FB:5F")

def get_marge_account_uuid(default_uuid="5476586"):
    """
    Récupération dynamique du margeAccountUUID.
    Priorité 1 : Fichier .env (SC_MARGE_ACCOUNT)[cite: 4]
    Priorité 2 : Interrogation API réseau Marge/Soundcork
    Priorité 3 : Valeur par défaut
    """
    if "SC_MARGE_ACCOUNT" in ENV_CONFIG:
        print("✅ ACCOUNT_UUID chargé depuis le fichier .env")
        return str(ENV_CONFIG["SC_MARGE_ACCOUNT"])

    try:
        r = requests.get(f"http://{MARGE_ADDR}:{MARGE_PORT}/info", timeout=2)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            uuid_node = root.find('.//margeAccountUUID')
            if uuid_node is not None and uuid_node.text:
                print(f"✅ ACCOUNT_UUID récupéré via l'API distante sur {MARGE_ADDR}:{MARGE_PORT}")
                return uuid_node.text
    except Exception:
        pass

    print(f"⚠️ Utilisation de l'ACCOUNT_UUID par défaut : {default_uuid}")
    return default_uuid

ACCOUNT_UUID = get_marge_account_uuid()

app = Flask(__name__)
# --- DESACTIVER LES LOGS HTTP DE FLASK ---
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)
# -----------------------------------------
ws_clients = []
device_presets = {}
media_servers = []

# --- MOTEUR AUDIO (VLC) & ETAT ---
class VirtualDevice:
    def __init__(self):
        # Configuration stricte pour BlueALSA
        self.vlc_instance = vlc.Instance('--no-video', '--aout=alsa', '--alsa-audio-device=bluealsa', '--quiet')
        self.player = self.vlc_instance.media_player_new()
        self.volume = 30
        self.is_muted = False
        self.player.audio_set_volume(self.volume)
        self.player.audio_set_mute(0)
        
        # État par défaut
        self.state = "STANDBY"
        self.source = "STANDBY"
        self.track = ""
        self.artist = ""
        self.album = ""
        self.art_url = ""
        
        # Paramètres étendus obligatoires pour sc_tools
        self.location = ""
        self.source_account = ""
        self.item_type = "stationurl"
        self.station_name = ""
        self.stream_type = "RADIO_STREAMING"
        
        self.shuffle = "SHUFFLE_OFF"
        self.repeat = "REPEAT_OFF"
        
        # Événements VLC
        self.events = self.player.event_manager()
        self.events.event_attach(vlc.EventType.MediaPlayerPlaying, self.on_playing)
        self.events.event_attach(vlc.EventType.MediaPlayerPaused, self.on_paused)
        self.events.event_attach(vlc.EventType.MediaPlayerEndReached, self.on_ended)
        self.events.event_attach(vlc.EventType.MediaPlayerEncounteredError, self.on_error)

    def on_playing(self, event):
        self.state = "PLAY_STATE"
        broadcast_update()

    def on_paused(self, event):
        self.state = "PAUSE_STATE"
        broadcast_update()

    def on_ended(self, event):
        self.state = "STOP_STATE"
        broadcast_update()

    def on_error(self, event):
        self.state = "STOP_STATE"
        broadcast_update()

    def play_url(self, url, source_type, title="Flux Audio", location="", source_account=""):
        # --- FORCER LA RECONNEXION BLUETOOTH AVANT DE JOUER ---
        try:
            subprocess.run(["bluetoothctl", "connect", BT_MAC_ADDRESS], 
                           stdout=subprocess.DEVNULL, 
                           stderr=subprocess.DEVNULL, 
                           timeout=3)
            time.sleep(0.5) # Le temps que BlueALSA recrée la carte son
        except Exception as e:
            print(f"Info BT : {e}")
        # ------------------------------------------------------

        media = self.vlc_instance.media_new(url)
        self.player.set_media(media)
        
        # Mémorisation stricte des attributs
        self.source = source_type
        self.track = title
        self.station_name = title
        self.location = location
        self.source_account = source_account
        self.state = "BUFFERING_STATE"
        
        if source_type in ["RADIO_BROWSER", "LOCAL_INTERNET_RADIO", "TUNEIN"]:
            self.item_type = "stationurl"
            self.stream_type = "RADIO_STREAMING"
        else:
            self.item_type = "track"
            self.stream_type = "TRACK_ONDEMAND"
            
        self.player.play()
        broadcast_update()

    def toggle_pause(self):
        if self.state == "PLAY_STATE":
            self.player.pause()
        elif self.state == "PAUSE_STATE":
            self.player.play()

    def set_volume(self, vol):
        self.volume = max(0, min(100, int(vol)))
        self.player.audio_set_volume(self.volume)
        if self.is_muted and self.volume > 0:
            self.is_muted = False
            self.player.audio_set_mute(0)
        broadcast_volume()

    def toggle_mute(self):
        self.is_muted = not self.is_muted
        self.player.audio_set_mute(1 if self.is_muted else 0)
        broadcast_volume()

device = VirtualDevice()

# --- TACHES DE FOND (Presets & DLNA) ---
def background_preset_sync():
    global device_presets
    while True:
        try:
            url = f"http://{MARGE_ADDR}:{MARGE_PORT}/marge/streaming/account/{ACCOUNT_UUID}/full"
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                root = ET.fromstring(r.content)
                dev = root.find(f".//device[@deviceid='{MAC_ADDRESS}']")
                if dev is not None:
                    presets_node = dev.find('presets')
                    if presets_node is not None:
                        new_presets = {}
                        for p in presets_node.findall('preset'):
                            btn = p.get('buttonNumber')
                            loc = p.findtext('location') or ''
                            name = p.findtext('name') or f'Preset {btn}'
                            
                            source = "LOCAL_INTERNET_RADIO"
                            if "/stations/byuuid" in loc:
                                source = "RADIO_BROWSER"
                            elif "1$F$1" in loc:
                                source = "STORED_MUSIC"
                            
                            new_presets[btn] = {
                                'source': source,
                                'location': loc,
                                'itemName': name
                            }
                        device_presets = new_presets
        except Exception:
            pass
        time.sleep(60)

def background_ssdp_discover():
    global media_servers
    msg = ('M-SEARCH * HTTP/1.1\r\n'
           'HOST: 239.255.255.250:1900\r\n'
           'MAN: "ssdp:discover"\r\n'
           'MX: 2\r\n'
           'ST: urn:schemas-upnp-org:device:MediaServer:1\r\n\r\n')
           
    while True:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.settimeout(2.5)
            sock.sendto(msg.encode('utf-8'), ('239.255.255.250', 1900))
            locations = set()
            
            while True:
                try:
                    data, addr = sock.recvfrom(2048)
                    for line in data.decode('utf-8', errors='ignore').split('\r\n'):
                        if line.lower().startswith('location:'):
                            locations.add(line.split(':', 1)[1].strip())
                except socket.timeout:
                    break
            sock.close()
            
            discovered = []
            for loc in locations:
                try:
                    r = requests.get(loc, timeout=2)
                    if r.status_code == 200:
                        friendly_name = re.search(r'<friendlyName>(.*?)</friendlyName>', r.text)
                        friendly_name = friendly_name.group(1) if friendly_name else 'Unknown'
                        
                        udn = re.search(r'<UDN>uuid:(.*?)</UDN>', r.text)
                        udn = udn.group(1) if udn else str(uuid.uuid4())
                        
                        manufacturer = re.search(r'<manufacturer>(.*?)</manufacturer>', r.text)
                        manufacturer = manufacturer.group(1) if manufacturer else ''
                        
                        model_name = re.search(r'<modelName>(.*?)</modelName>', r.text)
                        model_name = model_name.group(1) if model_name else ''
                        
                        model_desc = re.search(r'<modelDescription>(.*?)</modelDescription>', r.text)
                        model_desc = model_desc.group(1) if model_desc else ''
                        
                        ip = urllib.parse.urlparse(loc).hostname
                        
                        discovered.append({
                            'id': udn,
                            'ip': ip,
                            'manufacturer': manufacturer,
                            'model_name': model_name,
                            'friendly_name': friendly_name,
                            'model_description': model_desc,
                            'location': loc
                        })
                except Exception:
                    pass
            media_servers = discovered
        except Exception:
            pass
        time.sleep(60)

def resolve_and_play(source, location, item_name, source_account=""):
    url_to_play = None
    
    if source == "LOCAL_INTERNET_RADIO":
        url_to_play = location 
        if "orion/station?data=" in url_to_play:
            try:
                b64_data = url_to_play.split("data=")[1]
                decoded = json.loads(base64.b64decode(b64_data).decode('utf-8'))
                url_to_play = decoded.get('streamUrl')
            except Exception as e:
                print(f"Erreur de décodage Orion : {e}")
                
    elif source == "STORED_MUSIC":
        if location.startswith("http"):
            url_to_play = location
        else:
            print(f"⚠️ [DLNA] Le preset pointe vers un ID UPnP ({location}).")
            device.player.stop()
            device.source = "STANDBY"
            device.state = "STANDBY"
            broadcast_update()
            return
            
    elif source == "RADIO_BROWSER" and "byuuid" in location:
        uuid_station = location.split("/")[-1]
        try:
            r = requests.get(f"https://de1.api.radio-browser.info/json/stations/byuuid/{uuid_station}", timeout=5)
            if r.status_code == 200:
                url_to_play = r.json()[0].get('url')
        except Exception as e:
            print(f"Erreur RadioBrowser : {e}")

    if url_to_play and url_to_play.startswith("http"):
        print(f"▶️ Lecture de l'URL résolue : {url_to_play}")
        device.play_url(url_to_play, source, item_name, location, source_account)
    else:
        print(f"⚠️ Impossible de résoudre une URL HTTP valide pour la source {source}")
        device.player.stop()
        device.source = "STANDBY"
        device.state = "STANDBY"
        broadcast_update()

# --- GENERATEURS XML EXACTS (Bose Spec) ---
def generate_now_playing_xml():
    if device.source == "STANDBY":
        return f'<nowPlaying deviceID="{MAC_ADDRESS}" source="STANDBY"><ContentItem source="STANDBY" isPresetable="false" /></nowPlaying>'
        
    safe_track = saxutils.escape(device.track)
    safe_artist = saxutils.escape(device.artist)
    safe_album = saxutils.escape(device.album)
    safe_station = saxutils.escape(device.station_name)
    safe_location = saxutils.escape(device.location)
    
    current_time = max(0, device.player.get_time() // 1000)
    total_time = max(0, device.player.get_length() // 1000)
    time_node = f'<time total="{total_time}">{current_time}</time>' if total_time > 0 else ''
    
    return f'''<nowPlaying deviceID="{MAC_ADDRESS}" source="{device.source}" sourceAccount="{device.source_account}">
    <ContentItem source="{device.source}" type="{device.item_type}" location="{safe_location}" sourceAccount="{device.source_account}" isPresetable="true">
        <itemName>{safe_track}</itemName>
        <containerArt/>
    </ContentItem>
    <track>{safe_track}</track>
    <artist>{safe_artist}</artist>
    <album>{safe_album}</album>
    <stationName>{safe_station}</stationName>
    <art artImageStatus="SHOW_DEFAULT_IMAGE">{device.art_url}</art>
    {time_node}
    <playStatus>{device.state}</playStatus>
    <streamType>{device.stream_type}</streamType>
    <shuffleSetting>{device.shuffle}</shuffleSetting>
    <repeatSetting>{device.repeat}</repeatSetting>
</nowPlaying>'''

def generate_volume_xml():
    mute_str = "true" if device.is_muted else "false"
    return f'<volume deviceID="{MAC_ADDRESS}"><targetvolume>{device.volume}</targetvolume><actualvolume>{device.volume}</actualvolume><muteenabled>{mute_str}</muteenabled></volume>'

def generate_404_xml():
    return f'<?xml version="1.0" encoding="UTF-8" ?><errors deviceID="{MAC_ADDRESS}"><error value="1503" name="HTTP_NOT_FOUND" severity="Unknown">1503</error></errors>'

# --- GESTIONNAIRE WEBSOCKET NATIF ---
def ws_send(conn, msg):
    try:
        msg_bytes = msg.encode('utf-8')
        length = len(msg_bytes)
        frame = bytearray([0x81]) 
        
        if length <= 125:
            frame.append(length)
        elif length <= 65535:
            frame.append(126)
            frame.extend(length.to_bytes(2, 'big'))
        else:
            frame.append(127)
            frame.extend(length.to_bytes(8, 'big'))
            
        frame.extend(msg_bytes)
        conn.sendall(frame)
    except Exception:
        if conn in ws_clients:
            ws_clients.remove(conn)
        conn.close()

def broadcast_update():
    xml = f'<updates deviceID="{MAC_ADDRESS}"><nowPlayingUpdated>{generate_now_playing_xml()}</nowPlayingUpdated></updates>'
    for conn in list(ws_clients):
        ws_send(conn, xml)

def broadcast_volume():
    xml = f'<updates deviceID="{MAC_ADDRESS}"><volumeUpdated>{generate_volume_xml()}</volumeUpdated></updates>'
    for conn in list(ws_clients):
        ws_send(conn, xml)

def periodic_status_broadcast():
    while True:
        if device.state == "PLAY_STATE":
            # --- AUTO-STOP EN CAS DE DECONNEXION BLUETOOTH ---
            try:
                res = subprocess.run(["bluetoothctl", "info", BT_MAC_ADDRESS], capture_output=True, text=True)
                if "Connected: yes" not in res.stdout:
                    print("\n⚠️ Enceinte déconnectée ! Arrêt automatique de la lecture pour éviter le spam.")
                    device.player.stop()
                    device.source = "STANDBY"
                    device.state = "STANDBY"
            except Exception:
                pass
            # -------------------------------------------------
            broadcast_update()
        time.sleep(5) # Vérifie l'état toutes les 5 secondes

def handle_ws_client(conn):
    try:
        data = conn.recv(4096).decode('utf-8', errors='ignore')
        if not data: return
        
        key_match = re.search(r'Sec-WebSocket-Key:\s+(.*?)\r\n', data)
        if not key_match: return
        
        key = key_match.group(1).strip()
        accept_key = base64.b64encode(hashlib.sha1((key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode('utf-8')).digest()).decode('utf-8')
        
        response = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {accept_key}\r\n"
            "Sec-WebSocket-Protocol: gabbo\r\n\r\n"
        )
        conn.sendall(response.encode('utf-8'))
        ws_clients.append(conn)
        
        ws_send(conn, '<SoundTouchSdkInfo serverVersion="4" serverBuild="trunk r46330 v4 epdbuild hepdswbld04" />')
        ws_send(conn, f'<updates deviceID="{MAC_ADDRESS}"><nowPlayingUpdated>{generate_now_playing_xml()}</nowPlayingUpdated></updates>')
        ws_send(conn, f'<updates deviceID="{MAC_ADDRESS}"><volumeUpdated>{generate_volume_xml()}</volumeUpdated></updates>')
        
        while True:
            frame = conn.recv(4096)
            if not frame: break
            
            if len(frame) >= 2:
                opcode = frame[0] & 0x0F
                if opcode == 0x09:
                    pong_frame = bytearray([0x8A, frame[1]])
                    if len(frame) > 2:
                        pong_frame.extend(frame[2:])
                    conn.sendall(pong_frame) 
                elif opcode == 0x08: 
                    break
    except Exception as e:
        print(f"Erreur WS client: {e}")
    finally:
        if conn in ws_clients:
            ws_clients.remove(conn)
        conn.close()

def ws_server_loop():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('0.0.0.0', WS_PORT))
    server.listen(5)
    print(f"📡 Serveur WebSocket émulé en écoute sur le port {WS_PORT}...")
    
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_ws_client, args=(conn,), daemon=True).start()

# --- API HTTP ---
@app.route('/info', methods=['GET'])
def get_info():
    current_time = time.strftime('%Y-%m-%dT%H:%M:%S.000+00:00', time.gmtime())
    xml = f'''<?xml version="1.0" encoding="UTF-8" ?>
    <info deviceID="{MAC_ADDRESS}">
        <name>{DEVICE_NAME}</name>
        <type>SoundTouch Virtual</type>
        <components>
            <component>
                <componentCategory>SCM</componentCategory>
                <softwareVersion>27.0.6.46330.5043500</softwareVersion>
                <serialNumber>VIRTUAL-SCM-{MAC_ADDRESS}</serialNumber>
            </component>
        </components>
        <networkInfo type="SCM">
            <macAddress>{MAC_ADDRESS}</macAddress>
            <ipAddress>{LOCAL_IP}</ipAddress>
        </networkInfo>
        <margeAccountUUID>{ACCOUNT_UUID}</margeAccountUUID>
        <margeURL>http://{MARGE_ADDR}:{MARGE_PORT}/marge</margeURL>
        <createdOn>2012-09-19T12:43:00.000+00:00</createdOn>
        <updatedOn>{current_time}</updatedOn>
    </info>'''
    return Response(xml, mimetype='text/xml')

@app.route('/supportedURLs', methods=['GET'])
def get_supported_urls():
    urls = [
        "/info", "/capabilities", "/powerManagement", "/nowPlaying", "/volume", "/key", 
        "/select", "/presets", "/sources", "/listMediaServers", "/getGroup", "/notification", 
        "/masterMsg", "/slaveMsg", "/setZone", "/addZoneSlave", "/removeZoneSlave"
    ]
    xml = f'<?xml version="1.0" encoding="UTF-8" ?><supportedURLs deviceID="{MAC_ADDRESS}">'
    for url in urls:
        xml += f'<URL location="{url}" />'
    xml += '</supportedURLs>'
    return Response(xml, mimetype='text/xml')

@app.route('/listMediaServers', methods=['GET'])
def list_media_servers():
    xml = '<?xml version="1.0" encoding="UTF-8" ?>\n<ListMediaServersResponse>'
    for srv in media_servers:
        xml += f'<media_server id="{srv["id"]}" ip="{srv["ip"]}" manufacturer="{saxutils.escape(srv["manufacturer"])}" model_name="{saxutils.escape(srv["model_name"])}" friendly_name="{saxutils.escape(srv["friendly_name"])}" model_description="{saxutils.escape(srv["model_description"])}" location="{saxutils.escape(srv["location"])}" />'
    xml += '</ListMediaServersResponse>'
    return Response(xml, mimetype='text/xml')

@app.route('/sources', methods=['GET'])
def get_sources():
    xml = f'''<?xml version="1.0" encoding="UTF-8" ?>
    <sources deviceID="{MAC_ADDRESS}">
        <sourceItem source="LOCAL_INTERNET_RADIO" status="READY" isLocal="false" />
        <sourceItem source="RADIO_BROWSER" status="READY" isLocal="false" />
        <sourceItem source="BLUETOOTH" status="READY" isLocal="true" />
    '''
    for srv in media_servers:
        xml += f'<sourceItem source="STORED_MUSIC" sourceAccount="{srv["id"]}/0" status="READY" isLocal="false">{saxutils.escape(srv["friendly_name"])}</sourceItem>\n'
    xml += '</sources>'
    return Response(xml, mimetype='text/xml')

@app.route('/presets', methods=['GET'])
def get_presets():
    xml = '<?xml version="1.0" encoding="UTF-8" ?><presets>'
    for btn, data in device_presets.items():
        xml += f'''
        <preset id="{btn}">
            <ContentItem source="{data['source']}" location="{data['location']}" isPresetable="true">
                <itemName>{saxutils.escape(data['itemName'])}</itemName>
            </ContentItem>
        </preset>'''
    xml += '</presets>'
    return Response(xml, mimetype='text/xml')

@app.route('/nowPlaying', methods=['GET'])
def get_now_playing():
    xml = '<?xml version="1.0" encoding="UTF-8" ?>\n' + generate_now_playing_xml()
    return Response(xml, mimetype='text/xml')

@app.route('/volume', methods=['GET', 'POST'])
def handle_volume():
    if request.method == 'POST':
        try:
            root = ET.fromstring(request.data)
            if root.tag == 'volume':
                device.set_volume(int(root.text))
        except: pass
    xml = '<?xml version="1.0" encoding="UTF-8" ?>\n' + generate_volume_xml()
    return Response(xml, mimetype='text/xml')

@app.route('/key', methods=['POST'])
def handle_key():
    try:
        root = ET.fromstring(request.data)
        state = root.attrib.get('state')
        key = root.text
        
        if state in ['press', 'repeat']:
            if key == "VOLUME_UP": device.set_volume(device.volume + 2)
            elif key == "VOLUME_DOWN": device.set_volume(device.volume - 2)
        
        if state in ['release', None]:
            if key == "PLAY_PAUSE": device.toggle_pause()
            elif key == "PLAY":
                if device.state == "PAUSE_STATE":
                    device.player.play()
                    device.state = "PLAY_STATE"
                    broadcast_update()
            elif key == "PAUSE":
                if device.state == "PLAY_STATE":
                    device.player.pause()
                    device.state = "PAUSE_STATE"
                    broadcast_update()
            elif key == "STOP":
                device.player.stop()
                device.source = "STANDBY"
                device.state = "STANDBY"
                broadcast_update()
            elif key == "POWER":
                if device.state != "STANDBY":
                    device.player.stop()
                    device.source = "STANDBY"
                    device.state = "STANDBY"
                broadcast_update()
            elif key == "MUTE": device.toggle_mute()
            elif key == "SHUFFLE_ON": device.shuffle = "SHUFFLE_ON"; broadcast_update()
            elif key == "SHUFFLE_OFF": device.shuffle = "SHUFFLE_OFF"; broadcast_update()
            elif key in ["REPEAT_OFF", "REPEAT_ONE", "REPEAT_ALL"]:
                device.repeat = key
                broadcast_update()
            elif key == "AUX_INPUT":
                device.player.stop()
                device.source = "AUX"
                device.track = "Entrée Auxiliaire"
                device.item_type = "track"
                device.stream_type = "TRACK_ONDEMAND"
                device.state = "PLAY_STATE"
                broadcast_update()
            elif key.startswith("PRESET_"):
                preset_id = key.split('_')[1]
                if preset_id in device_presets:
                    p = device_presets[preset_id]
                    resolve_and_play(p['source'], p['location'], p['itemName'], "")
                
    except Exception as e:
        print(f"Erreur Key : {e}")
    return Response('<?xml version="1.0" encoding="UTF-8" ?><status>Gabbo</status>', mimetype='text/xml')

@app.route('/select', methods=['POST'])
def handle_select():
    try:
        root = ET.fromstring(request.data)
        source = root.attrib.get('source')
        location = root.attrib.get('location', '')
        source_account = root.attrib.get('sourceAccount', '')
        item_name = root.findtext('itemName') or 'Stream Inconnu'
        resolve_and_play(source, location, item_name, source_account)
    except Exception as e:
        print(f"Erreur Select : {e}")
    return Response('<?xml version="1.0" encoding="UTF-8" ?><status>Gabbo</status>', mimetype='text/xml')

@app.route('/powerManagement', methods=['GET'])
def get_power():
    xml = '<?xml version="1.0" encoding="UTF-8" ?><powerManagementResponse><powerState>FullPower</powerState><battery><capable>false</capable></battery></powerManagementResponse>'
    return Response(xml, mimetype='text/xml')

@app.route('/getGroup', methods=['GET'])
def get_group():
    return Response(generate_404_xml(), status=404, mimetype='text/xml')

@app.route('/getZone', methods=['GET'])
def get_zone():
    return Response('<?xml version="1.0" encoding="UTF-8" ?><zone />', mimetype='text/xml')

@app.route('/capabilities', methods=['GET'])
def get_capa():
    xml = f'''<?xml version="1.0" encoding="UTF-8" ?>
    <capabilities deviceID="{MAC_ADDRESS}">
        <networkConfig>
            <hostedWifiConfigWebPage/>
            <wsapiproxy>false</wsapiproxy>
            <allInterfacesSupported/>
            <wlanInterfaces/>
            <security/>
        </networkConfig>
        <dspCapabilities>
            <dspMonoStereo/>
        </dspCapabilities>
        <lightswitch>false</lightswitch>
        <clockDisplay>false</clockDisplay>
        <capability name="systemtimeout" url="/systemtimeout" info=""/>
        <capability name="rebroadcastlatencymode" url="/rebroadcastlatencymode" info=""/>
        <lrStereoCapable>false</lrStereoCapable>
        <bcoresetCapable>false</bcoresetCapable>
        <disablePowerSaving>true</disablePowerSaving>
    </capabilities>'''
    return Response(xml, mimetype='text/xml')

@app.route('/notification', methods=['POST'])
def handle_notification():
    return Response('<?xml version="1.0" encoding="UTF-8" ?><status>/notification</status>', mimetype='text/xml')

@app.route('/masterMsg', methods=['POST'])
def handle_master_msg():
    return Response('<?xml version="1.0" encoding="UTF-8" ?><status>/masterMsg</status>', mimetype='text/xml')

@app.route('/slaveMsg', methods=['POST'])
def handle_slave_msg():
    return Response('<?xml version="1.0" encoding="UTF-8" ?><status>/slaveMsg</status>', mimetype='text/xml')

@app.route('/setZone', methods=['POST'])
def set_zone():
    return Response('<?xml version="1.0" encoding="UTF-8" ?><status>/setZone</status>', mimetype='text/xml')

@app.route('/addZoneSlave', methods=['POST'])
def add_zone_slave():
    return Response('<?xml version="1.0" encoding="UTF-8" ?><status>/addZoneSlave</status>', mimetype='text/xml')

@app.route('/removeZoneSlave', methods=['POST'])
def remove_zone_slave():
    return Response('<?xml version="1.0" encoding="UTF-8" ?><status>/removeZoneSlave</status>', mimetype='text/xml')

# --- MDNS ANNONCE ---
def register_mdns():
    info = ServiceInfo(
        "_soundtouch._tcp.local.",
        f"{DEVICE_NAME}._soundtouch._tcp.local.",
        addresses=[socket.inet_aton(LOCAL_IP)],
        port=HTTP_PORT,
        properties={'MAC': MAC_ADDRESS.encode('utf-8')}
    )
    zeroconf = Zeroconf()
    zeroconf.register_service(info)
    print(f"🔊 Annonce mDNS envoyée : {DEVICE_NAME} ({MAC_ADDRESS}) sur {LOCAL_IP}")
    return zeroconf

if __name__ == '__main__':
    threading.Thread(target=ws_server_loop, daemon=True).start()
    threading.Thread(target=background_preset_sync, daemon=True).start()
    threading.Thread(target=background_ssdp_discover, daemon=True).start()
    threading.Thread(target=periodic_status_broadcast, daemon=True).start()
    zc = register_mdns()
    
    try:
        app.run(host='0.0.0.0', port=HTTP_PORT, threaded=True)
    finally:
        zc.close()
