#!/bin/bash

# ==============================================================================
# OPTIONS DE SÉCURITÉ
# ==============================================================================
set -euo pipefail

# ==============================================================================
# CONFIGURATION ET VARIABLES
# ==============================================================================
BACKUP_DIR="$HOME/.sauve"
DATE_SUFFIX=$(date +%Y%m%d-%H%M)

SAVE_NAME="${BACKUP_DIR}/sauve${DATE_SUFFIX}.7z"
SAVE_PARAM="${BACKUP_DIR}/param${DATE_SUFFIX}.7z"
LAST_SAVE="${BACKUP_DIR}/lastSave.7z"
LAST_PARAM="${BACKUP_DIR}/lastParam.7z"
LAST_UPDATE="${HOME}/sc_tools.lasted.7z"
TARGET_DIR="$HOME/sc_tools"


# ==============================================================================
# VÉRIFICATIONS PRÉALABLES
# ==============================================================================
if [ ! -d "$BACKUP_DIR" ]; then
    echo "Création du dossier de sauvegarde : $BACKUP_DIR"
    mkdir -p "$BACKUP_DIR"
fi

if [ -f "$LAST_SAVE" ]; then
    echo "Suppression de l'ancienne sauvegarde rapide (lastSave.7z)..."
    rm "$LAST_SAVE"
fi

# TRÈS IMPORTANT : On se place dans le HOME pour travailler en chemins relatifs
cd "$HOME"

# ==============================================================================
# OPÉRATIONS DE SAUVEGARDE
# ==============================================================================

echo "Début de la sauvegarde globale..."
# Utilisation des chemins relatifs pour conserver la structure des dossiers
7z a -t7z -mx=9 "$SAVE_NAME" \
    "sc_tools" \
    "soundcork/data" \
    '-xr!*.7z' \
    '-xr!*.zip' \
    '-xr!*.mp3'

echo "Début de la sauvegarde des paramètres et configurations..."
# L'ajout de '|| [ $? -eq 1 ]' tolère les warnings (ex: fichier .env manquant) 
#    sans faire cracher le script, tout en bloquant sur les vraies erreurs (code 2+).
7z a -t7z -mx=9 "$SAVE_PARAM" \
    "soundcork/docker-compose.yml" \
    "soundcork/Dockerfile" \
    "soundcork/requirements.txt" \
    "soundcork/data" \
    "soundcork-stockholm-app/docker-compose.yml" \
    "soundcork-stockholm-app/.env" \
    "soundcork-stockholm-app/Dockerfile" \
    "soundcork-stockholm-app/config/" \
    "sc_tools/docker-compose.yml" \
    "sc_tools/Dockerfile" \
    "sc_tools/requirements.txt" \
    "sc_tools/rf/Dockerfile" \
    "sc_tools/rf/requirements.txt" \
    "sc_tools/data/" \
    '-xr!*.mp3' || [ $? -eq 1 ]

# ==============================================================================
# FINALISATION SAUVEGARDE
# ==============================================================================
echo "Mise à jour du fichier de référence 'lastSave.7z et lastParam.7z'..."
cp "$SAVE_NAME" "$LAST_SAVE"
cp "$SAVE_PARAM" "$LAST_PARAM"

echo "Sauvegarde terminée avec succès !"

# ==============================================================================
# NOUVELLE VERSION DE SC_TOOLS
# DÉPLOIEMENT ET EXTRACTION
# ==============================================================================
cd "$HOME"

# Extraction de la mise à jour globale
if [ -f "$LAST_UPDATE" ]; then
    echo "Extraction de la nouvelle version globale..."
    # -y : Répond automatiquement 'Oui' pour écraser les anciens fichiers
    7z x -y "$LAST_UPDATE"
    
    echo "Nettoyage de l'archive de mise à jour..."
    rm "$LAST_UPDATE"
else
    echo "Avertissement : Archive globale introuvable ($LAST_UPDATE)"
fi

# Extraction des paramètres (si la variable est définie et le fichier existe)
if [ -n "$LAST_PARAM" ] && [ -f "$LAST_PARAM" ]; then
    echo "Restauration des paramètres spécifiques..."
    7z x -y "$LAST_PARAM"
fi

# ==============================================================================
# OPTIMISATION ET SÉCURISATION DES PERMISSIONS
# ==============================================================================
echo "Application des permissions sécurisées sur $TARGET_DIR..."

if [ -d "$TARGET_DIR" ]; then
    # 1. Dossiers : Réduits de 777 à 775 (Propriétaire & Groupe peuvent écrire, pas le reste du monde)
    find "$TARGET_DIR" -type d -exec chmod 775 {} +

    # 2. Fichiers généraux : Réduits de 666 à 664 (Lecture/Écriture pour le propriétaire & groupe)
    find "$TARGET_DIR" -type f -exec chmod 664 {} +

    # 3. Scripts exécutables : 775 (Lecture/Écriture/Exécution pour propriétaire & groupe)
    find "$TARGET_DIR" -type f -name "*.sh" -exec chmod 775 {} +
    
    echo "Permissions mises à jour avec succès."
else
    echo "Erreur : Le dossier cible $TARGET_DIR n'existe pas." >&2
    exit 1
fi
curl -X POST -H "Content-Type: text/plain" -d "$(date +"%Y%m%d%H%M") : $(hostname -I) : SETUP OK" "https://phd.dsmynas/webhook.php?token=G7pL9%vX$mQ2@zWG,juf"

echo "Déploiement terminé !"