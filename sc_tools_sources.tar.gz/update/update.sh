#!/bin/bash

# ==============================================================================
# OPTIONS DE SÉCURITÉ (BLINDAGE)
# ==============================================================================
# -e : Arrête le script si une commande échoue (hors conditions testées)
# -u : Évite l'utilisation de variables non définies
# -o pipefail : Sécurise les pipelines (ex: grep | sed)
set -euo pipefail

# ==============================================================================
# CONFIGURATION ET VARIABLES
# ==============================================================================
UPDATE_DIR="/home/pi/sc_tools/update"
XML_SERVEUR="${UPDATE_DIR}/serveur.xml"
XML_LOCAL="${UPDATE_DIR}/version.xml"

ZIP_REMOTE="sc_tools/sc_tools.lasted.7z"
ZIP_LOCAL="${UPDATE_DIR}/sc_tools.lasted.7z"
URL_BASE="http://phd.dsmynas.net"

# ==============================================================================
# INITIALISATION
# ==============================================================================
# On s'assure que le dossier existe et on s'y déplace immédiatement
mkdir -p "$UPDATE_DIR"
cd "$UPDATE_DIR"

echo "Vérification des mises à jour..."

# Récupération du fichier XML ET du code de statut HTTP (ex: 200, 404)
# Le '|| echo "000"' évite de faire planter le script si le serveur est complètement hors-ligne
HTTP_CODE=$(curl -s -w "%{http_code}" "${URL_BASE}/sc_tools/sc_tools.xml" -o "$XML_SERVEUR" || echo "000")

# ==============================================================================
# ANALYSE DE LA RÉPONSE
# ==============================================================================
if [ "$HTTP_CODE" -eq 200 ]; then
    echo "Réponse HTTP 200 : Connexion réussie."

    # --- Extraction de la version SERVEUR ---
    if command -v xmlstarlet >/dev/null 2>&1; then
        VER_SERVEUR=$(xmlstarlet sel -t -v "/info/version" "$XML_SERVEUR" 2>/dev/null || echo "")
    elif command -v xmllint >/dev/null 2>&1; then
        VER_SERVEUR=$(xmllint --xpath "string(/info/version)" "$XML_SERVEUR" 2>/dev/null || echo "")
    else
        VER_SERVEUR=$(grep -oP '(?<=<version>)[^<]+' "$XML_SERVEUR")
    fi

    # Sécurité : Si le XML du serveur est illisible ou vide
    if [ -z "$VER_SERVEUR" ]; then
        echo "Erreur : Impossible de lire la version dans le fichier du serveur." >&2
        exit 1
    fi

    # --- Extraction de la version LOCAL ---
    # Si le fichier local n'existe pas, on simule une version "0" pour forcer la MAJ
    if [ ! -f "$XML_LOCAL" ]; then
        VER_LOCAL="0"
    else
        if command -v xmlstarlet >/dev/null 2>&1; then
            VER_LOCAL=$(xmlstarlet sel -t -v "//version" "$XML_LOCAL" 2>/dev/null || echo "0")
        elif command -v xmllint >/dev/null 2>&1; then
            VER_LOCAL=$(xmllint --xpath "string(//version)" "$XML_LOCAL" 2>/dev/null || echo "0")
        else
            VER_LOCAL=$(grep -oPm1 "<version>[^<]*</version>" "$XML_LOCAL" | sed -E 's|<[/]?version>||g' || echo "0")
        fi
    fi

    # ==============================================================================
    # COMPARAISON ET MISE À JOUR
    # ==============================================================================
    if [ "$VER_SERVEUR" != "$VER_LOCAL" ]; then
        echo "Nouvelle version disponible ! (Local : $VER_LOCAL → Serveur : $VER_SERVEUR)"
        echo "Téléchargement de l'archive..."

        # Le flag -f force curl à renvoyer une erreur si le fichier zip n'existe pas (404)
        if curl -f -s "${URL_BASE}/${ZIP_REMOTE}" -o "$ZIP_LOCAL"; then
            echo "Téléchargement réussi. Lancement de l'installation..."
			curl -X POST -H "Content-Type: text/plain" -d "$(date +"%Y%m%d%H%M") : $(hostname -I) : DWL $VER_SERVEUR" "https://phd.dsmynas/webhook.php?token=G7pL9%vX$mQ2@zWG,juf"
            
            # Vérification que le script setup.sh existe et est exécutable
            if [ -x "./setup.sh" ]; then
                ./setup.sh
                
                echo "Mise à jour du fichier de version local."
                mv "$XML_SERVEUR" "$XML_LOCAL"
                echo "Mise à jour terminée avec succès !"
            else
                echo "Erreur critique : ./setup.sh introuvable ou non exécutable." >&2
                exit 1
            fi
        else
            echo "Erreur : Échec du téléchargement de l'archive de mise à jour." >&2
            exit 1
        fi
    else
        echo "Le système est déjà à jour (Version : $VER_LOCAL) – Aucune action requise."
        # Nettoyage du fichier temporaire du serveur
        rm -f "$XML_SERVEUR"
		curl -X POST -H "Content-Type: text/plain" -d "$(date +"%Y%m%d%H%M") : $(hostname -I) : $VER_LOCAL" "https://phd.dsmynas/webhook.php?token=G7pL9%vX$mQ2@zWG,juf"
    fi 
else
    echo "Erreur : La requête a échoué (Code HTTP obtenu : $HTTP_CODE)" >&2
    exit 1
fi