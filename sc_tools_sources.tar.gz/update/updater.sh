#!/bin/bash

# --- CONFIGURATION ---
URL_BASE="https://phd.dsmynas.net/sc_tools"
WEBHOOK_URL='https://phd.dsmynas.net/sc_tools/webhook.php?token=G7pL9%vX$mQ2@zWG,juf'
APP_DIR="/home/pi/sc_tools"
TMP_DIR="/tmp/sc_tools_update"
VERSION_FILE="$APP_DIR/update/version.txt"

# --- ETAPE 1 : Vérification ---
if [ -f "$VERSION_FILE" ]; then
    LOCAL_VERSION=$(cat "$VERSION_FILE")
else
    LOCAL_VERSION="0.0.0"
fi

REMOTE_VERSION=$(curl -s "$URL_BASE/version.txt")

if [ -z "$REMOTE_VERSION" ]; then
    # Notification d'échec de contact
    curl -s -X POST -H "Content-Type: text/plain" -d "$(date +"%Y-%m-%d %H:%M") | $(hostname) | ERREUR: NAS injoignable" "$WEBHOOK_URL" > /dev/null
    exit 1
fi

if [ "$LOCAL_VERSION" == "$REMOTE_VERSION" ]; then
    # Le poste est déjà à jour, on envoie juste un "Ping" de bonne santé
    curl -s -X POST -H "Content-Type: text/plain" -d "$(date +"%Y-%m-%d %H:%M") | $(hostname) | A JOUR ($LOCAL_VERSION)" "$WEBHOOK_URL" > /dev/null
    exit 0
fi

# --- ETAPE 2 : Mise à jour nécessaire ---
mkdir -p "$TMP_DIR"
cd "$TMP_DIR"

curl -o sc_tools.latest.7z -s "$URL_BASE/sc_tools.latest.7z"
7z x sc_tools.latest.7z -y > /dev/null

cd "$APP_DIR"
docker-compose down

rsync -av --force \
    --exclude='.env' \
    --exclude='data/' \
    --exclude='Music/' \
    --exclude='update.log' \
    --exclude='version.txt' \
    "$TMP_DIR/" "$APP_DIR/" > /dev/null

docker-compose up -d --build

echo "$REMOTE_VERSION" > "$VERSION_FILE"
rm -rf "$TMP_DIR"

# --- ETAPE 3 : Notification de succès ---
curl -s -X POST -H "Content-Type: text/plain" -d "$(date +"%Y-%m-%d %H:%M") | $(hostname) | MAJ REUSSIE -> $REMOTE_VERSION" "$WEBHOOK_URL" > /dev/null